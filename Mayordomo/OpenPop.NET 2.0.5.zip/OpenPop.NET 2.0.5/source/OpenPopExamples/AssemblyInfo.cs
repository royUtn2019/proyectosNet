using System.Reflection;

[assembly: AssemblyTitle("OpenPop Example library")]
[assembly: AssemblyDescription("See the SourceCode for examples")]