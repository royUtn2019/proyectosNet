Thank you for downloading OpenPop.NET.

== Binaries ==
The only thing you will need is the OpenPop.NET binaries located in the binaries folder.
There are two version - one with a strong name, and one with a weak name.
If you do not know the difference of strongly named and weakly named assemblies - just pick one.

== Source code ==
The sourcecode is located in the source folder.
Visual studio 2010 has been used to compile the project.
Notice: there might be newer versions of the sourcecode available on the subversion repository.

== Test application ==
There is a test application included in the release.
It is suggested to try this application to see how the application works and how email messages are structured.

== Website with examples ==
Examples are available at http://hpop.sourceforge.net/

== Problems? ==
If you have any problems, don't hesitate sending an email to hpop-users@lists.sourceforge.net